CREATE TABLE cars (
    id INT PRIMARY KEY,
    brand VARCHAR(50),
    model VARCHAR(50),
    year INT,
    color VARCHAR(30),
    owner VARCHAR(100)
);

INSERT INTO cars (id, brand, model, year, color, owner)
VALUES
(1, 'Chevrolet', 'Cobalt', 2022, 'Oq', 'Ali Valiyev'),
(2, 'Chevrolet', 'Malibu', 2023, 'Qora', NULL),
(3, 'Toyota', 'Camry', 2021, 'Oq', 'Sardor Akmalov'),
(4, 'BMW', 'M5', 2024, 'Ko‘k', NULL),
(5, 'Mercedes', 'E200', 2022, 'Qora', 'Jasur Olimov'),
(6, 'Kia', 'K5', 2023, 'Kulrang', 'Bekzod Sobirov'),
(7, 'Hyundai', 'Sonata', 2020, 'Oq', NULL);

SELECT * FROM cars;

DROP TABLE cars;

CREATE TABLE cars (
    id INT PRIMARY KEY,
    brand VARCHAR(50),
    model VARCHAR(50),
    year INT,
    color VARCHAR(30),
    owner VARCHAR(100)
);

INSERT INTO cars (id, brand, model, year, color, owner)
VALUES
(1, 'Chevrolet', 'Onix', 2024, 'Oq', 'Ali'),
(2, 'Toyota', 'Corolla', 2023, 'Qora', 'Vali'),
(3, 'BMW', 'X5', 2024, 'Ko‘k', 'Sardor');

SELECT * FROM cars;