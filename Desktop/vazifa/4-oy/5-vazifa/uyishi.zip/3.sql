DROP TABLE IF EXISTS employees;

CREATE TABLE employees (
    id INT PRIMARY KEY,
    full_name VARCHAR(100),
    age INT,
    position VARCHAR(50),
    phone VARCHAR(20)
);

INSERT INTO employees (id, full_name, age, position, phone)
VALUES
(1, 'Ali Valiyev', 25, 'Dasturchi', '901234567'),
(2, 'Vali Karimov', 30, 'Menejer', '912345678'),
(3, 'Sardor Akmalov', 28, 'Dizayner', NULL),
(4, 'Jasur Olimov', 35, 'Direktor', '933456789'),
(5, 'Bekzod Sobirov', 23, 'Dasturchi', '945678901');

SELECT * FROM employees;

DROP TABLE employees;